# Guardar adjuntos de Outlook en el escritorio con Power Automate

Guion para una exposición de 15–20 minutos. Caso: Outlook de Microsoft 365, Windows 11 y escritorio sincronizado con OneDrive de la misma cuenta de trabajo o estudios.

Esta guía se elaboró a partir del tema que indicaste. No es una transcripción ni una reproducción verificada del video https://www.youtube.com/watch?v=o-nHaaWrMNI: el entorno no permitió acceder a YouTube. Los nombres de algunos botones pueden variar según el idioma y el diseñador.

## 1. Objetivo y frase de apertura — 1 minuto

“Hoy vamos a automatizar una tarea repetitiva: guardar los archivos adjuntos que llegan al correo. Usaremos Outlook, Power Automate y OneDrive. Al final, enviaremos un correo con dos archivos y comprobaremos que aparecen en una carpeta de nuestro escritorio”.

Resultado esperado: un correo NUEVO con asunto `DEMO-ADJUNTOS` y dos adjuntos reales genera dos archivos en `Escritorio > Adjuntos_Correo`.

## 2. Qué es Power Automate y cuáles son sus componentes — 3 minutos

Power Automate permite crear automatizaciones. Un flujo de nube conecta servicios; Power Automate para escritorio automatiza tareas de Windows. En este ejemplo usamos un flujo de nube y la sincronización de OneDrive.

| Componente | Explicación sencilla | Ejemplo de esta demostración |
|---|---|---|
| Flujo | La automatización completa | Guardar adjuntos de Outlook |
| Desencadenador o disparador | El evento que inicia el flujo | Cuando llega un nuevo correo electrónico (V3) |
| Acción | Un trabajo que realiza el flujo | Crear archivo en OneDrive para la Empresa |
| Conector | La integración con un servicio | Office 365 Outlook; OneDrive para la Empresa |
| Conexión | La sesión autenticada que permite usar ese servicio | La cuenta de trabajo autorizada para Outlook y OneDrive |
| Parámetro | Un dato de configuración de un paso | Carpeta Bandeja de entrada; filtro de asunto |
| Contenido dinámico | Un valor que llega de un paso anterior durante la ejecución | Nombre y contenido del adjunto actual |
| Aplicar a cada uno | Un bucle que repite pasos para cada elemento de una lista | Guardar el primer adjunto, luego el segundo |
| Condición | Una decisión con ramas Sí/No | ¿El adjunto es en línea? Si es falso, guardarlo |
| Expresión | Una fórmula que calcula un valor | Agregar un identificador único al nombre del archivo |
| Historial de ejecuciones | El registro de lo que ocurrió y de los errores | Revisar si el correo produjo dos archivos |

“El conector es el puente hacia el servicio; la conexión es la cuenta autorizada que usamos en ese puente. El desencadenador inicia y la acción ejecuta”.

En el portal: **Crear** permite iniciar un flujo; **Mis flujos** permite abrirlo; el **diseñador** organiza sus pasos; **Guardar** conserva la configuración; **Probar** ayuda a comprobarla. El historial permite revisar entradas y salidas de cada ejecución.

## 3. Preparar la carpeta del escritorio — 2 minutos

1. En Windows 11, abre el escritorio y crea una carpeta llamada `Adjuntos_Correo`.
2. Abre esa carpeta y revisa la ruta en la barra de direcciones del Explorador. Debe pertenecer al OneDrive que usarás en el flujo. Una ruta de ejemplo es `C:\Users\TU_USUARIO\OneDrive - TU_ORGANIZACION\Escritorio\Adjuntos_Correo`; el nombre real puede variar.
3. Entra en **OneDrive en la web**, con esa misma cuenta de trabajo, y busca la carpeta en **Mis archivos > Escritorio > Adjuntos_Correo**. En algunas instalaciones, Escritorio aparece como `Desktop`.
4. Confirma que puedes ver la misma carpeta desde Windows y desde OneDrive web. Si no aparece en la web, revisa la cuenta y la copia de seguridad del escritorio antes de continuar.
5. Si es necesario y está permitido por tu organización, abre la configuración de OneDrive: **Sincronización y copia de seguridad > Administrar copia de seguridad > Escritorio**. Activarla puede mover carpetas; para la presentación conviene llevar esto preparado y probado.

“Nuestro flujo guardará en OneDrive. El cliente de OneDrive sincroniza esos archivos con la carpeta visible en el escritorio”.

No se necesita puerta de enlace para esta opción. La PC puede estar apagada cuando se guarda el archivo en la nube; lo recibirá al encenderse y sincronizar. Para abrir los archivos sin conexión, comprueba su descarga o utiliza **Mantener siempre en este dispositivo**.

## 4. Crear el flujo y configurar el desencadenador — 3 minutos

1. Abre https://make.powerautomate.com con tu cuenta de trabajo o estudios. Verifica que puedes crear flujos y usar los conectores; las políticas de tu organización pueden limitarlo.
2. Selecciona **Crear > Flujo de nube automatizado**.
3. Escribe el nombre `Guardar adjuntos en Escritorio`.
4. Busca el conector **Office 365 Outlook** y el desencadenador **Cuando llega un nuevo correo electrónico (V3)** / **When a new email arrives (V3)**. No elijas Outlook.com para este caso.
5. Crea o selecciona la conexión con tu cuenta de correo.
6. Configura estos parámetros. Según el diseñador, algunos se muestran en **Agregar nuevos parámetros** u opciones avanzadas:

| Campo | Valor para la demostración | Para qué sirve |
|---|---|---|
| Carpeta | Bandeja de entrada / Inbox | Buzón que vigila el flujo |
| Solo con datos adjuntos | Sí | Evita procesar correos sin adjuntos |
| Incluir datos adjuntos | Sí | Incluye el contenido de los archivos para este ejemplo |
| Filtro de asunto | `DEMO-ADJUNTOS` | Limita la prueba a correos cuyo asunto contiene ese texto |

“Un flujo automatizado reacciona a un evento. En nuestro caso, espera un correo nuevo que cumpla estas condiciones”.

Usa tu buzón normal. Un buzón compartido requiere su desencadenador específico y los permisos correspondientes. Los correos antiguos no se procesan automáticamente al crear este flujo.

## 5. Recorrer los adjuntos y crear cada archivo — 3 minutos

1. Añade el control **Aplicar a cada uno** / **Apply to each**.
2. En la lista de entrada, selecciona **Datos adjuntos / Attachments** del desencadenador.
3. Dentro del bucle, añade una **Condición**: el campo del adjunto actual **Es en línea / Is Inline** es igual al booleano `false`. En el editor de expresiones puedes introducir `false` sin comillas. Esto evita guardar imágenes incrustadas, como algunos logotipos de firmas.
4. En la rama **Sí** de esa condición, añade la acción **Crear archivo / Create file** del conector **OneDrive para la Empresa / OneDrive for Business**. La rama No no necesita acciones.
5. Selecciona o autentica la conexión de OneDrive de la cuenta donde se encuentra el escritorio sincronizado.
6. Completa los campos:

| Campo de Crear archivo | Contenido |
|---|---|
| Ruta de carpeta | Selecciona con el explorador de OneDrive `Escritorio/Adjuntos_Correo` o la ubicación real que comprobaste en la web |
| Nombre de archivo | **Nombre / Name** del adjunto actual |
| Contenido del archivo | **Contenido / ContentBytes** del adjunto actual, no el cuerpo del correo ni el identificador del archivo |

Usa el contenido dinámico del adjunto actual, dentro del bucle. El diseñador puede crear el bucle automáticamente al elegir una lista; comprueba que no queden dos bucles innecesarios. En Ruta de carpeta no escribas una ruta de Windows como `C:\Users\...`; ese campo pertenece a OneDrive.

Para este ejemplo activa Incluir datos adjuntos y usa archivos pequeños. Si el contenido no está disponible, una alternativa es **Obtener datos adjuntos (V2) / Get Attachment (V2)** de Office 365 Outlook dentro del bucle, con **Id. del mensaje** del desencadenador e **Id. del adjunto** actual. Pasa el contenido devuelto a Crear archivo. Este patrón también permite recuperar el contenido bajo demanda; no hace falta añadirlo si la prueba ya recibe correctamente ContentBytes.

## 6. Demostración de escritorio: prueba completa — 3 minutos

Prepara dos archivos de muestra sin datos sensibles: `Demo_Factura_001.pdf` y `Demo_Resumen_001.xlsx`. Usa nombres nuevos en cada prueba.

1. Guarda el flujo y verifica que esté activado.
2. Selecciona **Probar > Manualmente**, si esa opción aparece, para observar una nueva ejecución.
3. Desde otra cuenta o con ayuda de un compañero, envía un correo NUEVO al buzón vigilado, con asunto `DEMO-ADJUNTOS 001` y ambos archivos adjuntos. Evita pegar imágenes dentro del cuerpo.
4. Espera a que el flujo se ejecute. El tiempo depende del servicio y del tipo de cuenta; no prometas que será instantáneo.
5. En el historial, abre la ejecución y comprueba que el bucle recorrió ambos adjuntos reales y que Crear archivo finalizó correctamente para cada uno.
6. Abre OneDrive web: deben aparecer exactamente esos dos archivos de prueba en la carpeta elegida.
7. En Windows 11, abre **Escritorio > Adjuntos_Correo**, espera la sincronización y abre ambos archivos para comprobar que su contenido es válido.
8. Envía opcionalmente otro correo con asunto `OTRO ASUNTO` y un adjunto: no debe generar un archivo con este filtro. Un correo sin adjuntos tampoco debe guardarse.

“Hemos comprobado tres cosas: llegó el correo correcto, se crearon los dos archivos en OneDrive y aparecieron en el escritorio gracias a la sincronización”.

Este documento y las diapositivas describen la prueba; el flujo no ha sido creado ni ejecutado en tu cuenta desde este chat. Ensáyalo antes de la exposición y guarda capturas del historial, de OneDrive y del escritorio como respaldo.

## 7. Problemas frecuentes y mejora del nombre — 2 minutos

| Problema | Qué revisar |
|---|---|
| No aparece ninguna ejecución | Flujo activo, correo nuevo, carpeta y filtro de asunto correctos, conexión de Outlook |
| Está en OneDrive web, pero no en el escritorio | Misma cuenta y carpeta, OneDrive iniciado, sincronización sin pausa ni errores |
| El archivo se crea, pero no abre o queda vacío | Contenido del adjunto actual; no usar el cuerpo del correo o su ID |
| Se guardan imágenes de la firma | Condición Is Inline = false; si es necesario, agrega un filtro por extensión |
| Falla al guardar otro archivo con el mismo nombre | No presupongas que Crear archivo lo renombra o sobrescribe; usa nombres únicos |
| La organización bloquea una conexión o acción | Revisa permisos y políticas con el administrador; no sustituyas cuentas sin autorización |

Mejora opcional para nombres únicos: en **Nombre de archivo**, usa esta expresión dentro del bucle. `item()` debe referirse al adjunto actual:

```
concat(formatDateTime(utcNow(),'yyyyMMdd_HHmmss_fff'),'_',guid(),'_',item()?['name'])
```

Conserva el nombre y la extensión al final. El identificador evita colisiones por nombres repetidos, pero no evita guardar otra copia si el mismo correo vuelve a procesarse. Para evitar duplicados de procesamiento haría falta registrar el ID del mensaje y el del adjunto.

## 8. ¿Qué cambia si la carpeta es solo local? — 1 minuto

Una carpeta local que no está en OneDrive requiere otro mecanismo. Dos alternativas:

- **Flujo de nube + conector File System / Sistema de archivos + puerta de enlace de datos local en modo estándar**: un administrador instala/configura la puerta de enlace en un equipo con acceso a la carpeta y una conexión con permisos de escritura. El equipo y la puerta de enlace deben estar disponibles. Se sustituye la acción de OneDrive por Crear archivo de File System. Se deben comprobar compatibilidad, políticas y derechos de uso de la organización.
- **Power Automate para escritorio**: automatiza operaciones en Windows. Es un flujo distinto; su configuración, Outlook compatible y requisitos de ejecución deben verificarse. No es necesario para el ejemplo de escritorio sincronizado de esta presentación.

## Preparación para mañana

- Comprueba que Outlook y OneDrive corresponden a las cuentas elegidas y que la carpeta está visible en la web.
- Crea y prueba el flujo con dos archivos pequeños y sin datos sensibles.
- Lleva el correo de prueba listo, nombres nuevos para cada ensayo y capturas de respaldo.
- Abre el portal, OneDrive web y la carpeta del escritorio antes de empezar.
- Explica los componentes mientras recorres el flujo, y reserva tres minutos para la demostración.

## Referencias oficiales

- Desencadenadores de correo: https://learn.microsoft.com/power-automate/email-triggers
- Conector Office 365 Outlook: https://learn.microsoft.com/connectors/office365/
- Conector OneDrive para la Empresa: https://learn.microsoft.com/connectors/onedriveforbusiness/
- Conector File System: https://learn.microsoft.com/connectors/filesystem/
- Puerta de enlace: https://learn.microsoft.com/power-automate/gateway-reference

La documentación de desencadenadores se contrastó mediante el repositorio oficial MicrosoftDocs/power-automate-docs. Las demás referencias se incluyen para consulta de campos, límites y requisitos actualizados.
